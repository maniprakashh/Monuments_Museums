import React from 'react'
import Layout from '../components/Layout/Layout'

const Policy = () => {
  return (
    <Layout title={"Privacy Policy"} >
        <h1>Privacy Policy Page</h1>
    </Layout>
  )
}

export default Policy